<?php
/**
 * CasinoFeed
 *
 * @package           CasinoFeed
 * @author            Dragomir Ivanov
 * @copyright         2020 Elegance Net ltd
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Casino Feed
 * Plugin URI:        https://elegancedesign.net/igaming
 * Description:       Casino feed with centralized database.
 * Version:           1.0.9
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Dragomir Ivanov
 * Author URI:        https://elegancedesign.net
 * Text Domain:       casinofeed
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

require_once 'SyncHelper.php';
require_once 'DatabaseHelper.php';
require_once 'TaxonomyHelper.php';
require_once 'plugin-update-checker/plugin-update-checker.php';

ini_set('error_reporting', 1);
ini_set('display_errors', 1);

$MyUpdateChecker = PucFactory::buildUpdateChecker(
    get_option('casinofeed_api_url') . '/plugin-metadata',
    __FILE__,
    'casinofeed-plugin'
);

class Casino_Feed
{
    const LICENSE_KEY_STATUS_INACTIVE = 0;
    const LICENSE_KEY_STATUS_ACTIVE = 1;

    const UPDATE_TYPE_MANUAL = 'manual';
    const UPDATE_TYPE_AUTOMATIC = 'automatic';

    public function init()
    {
        add_shortcode('casino-bonus', array($this, 'casino_bonus_shortcode'));
        add_shortcode('casino-data', array($this, 'casino_data_shortcode'));

        add_action('admin_enqueue_scripts', array($this, 'casino_feed_admin_styles'));
        add_action('wp_cron_casino_feed_automatic_sync', array($this, 'casinofeed_sync_data'));
        add_action('rest_api_init', array($this, 'casinofeed_register_status_enrpoint'));

        if (is_admin())
        {
            add_action('admin_menu', array($this, 'casino_feed_menus'));
            add_action('wp_ajax_casinofeed_set_license_key', array($this, 'casinofeed_set_license_key'));
            add_action('wp_ajax_casinofeed_set_update_type', array($this, 'casinofeed_set_update_type'));
            add_action('wp_ajax_casinofeed_sync_data', array($this, 'casinofeed_sync_data'));
            add_action('wp_ajax_casinofeed_sync_taxonomy', array($this, 'casinofeed_sync_taxonomy'));
            add_action('wp_ajax_casinofeed_approve_all', array($this, 'casinofeed_approve_all'));
            add_action('wp_ajax_casinofeed_approve_change', array($this, 'casinofeed_approve_change'));
            add_action('wp_ajax_casinofeed_skip_change', array($this, 'casinofeed_skip_change'));
            add_action('wp_ajax_casinofeed_preview_shortcode', array($this, 'casinofeed_preview_shortcode'));
			
			//elegance importer
            add_action('wp_ajax_casinofeed_download_brand', array($this, 'casinofeed_download_brand'));
        }
    }

    public function casino_feed_admin_styles()
    {
        wp_enqueue_script('casino-feed-admin-js', plugin_dir_url(__FILE__) . 'js/casino-feed-admin.js', array('jquery'), '1.0.0', false);
        //elegance importer
        wp_enqueue_script('casino-feed-admin-download-js', plugin_dir_url(__FILE__) . 'js/casino-feed-admin-importer.js', array('jquery'), '1.0.0', false);

        wp_register_style('casino-feed-admin-css', plugin_dir_url(__FILE__) . 'css/casino-feed-admin.css');
        wp_enqueue_style('casino-feed-admin-css');
    }

    public function casino_feed_menus()
    {
        add_menu_page(
            'Casino Feed',
            'Casino Feed',
            'manage_options',
            'casino_feed',
            function ()
            {
                require(plugin_dir_path(__FILE__) . 'views/updates.php');
            },
            plugin_dir_url(__FILE__) . 'images/icon.png',
            20
        );
        add_submenu_page(
            'casino_feed',
            'Feed Browser',
            'Feed Browser',
            'manage_options',
            'casino_feed_browser',
            function ()
            {
                require(plugin_dir_path(__FILE__) . 'views/browser.php');
            }
        );

        $theme = wp_get_theme(); // gets the current theme
        if ('Gambler Desk' == $theme->name || 'Gambler Desk' == $theme->parent_theme
            || 'Casino Feed' == $theme->name || 'Casino Feed' == $theme->parent_theme)
        {
            //elegance importer
            add_submenu_page(
                'casino_feed',
                'Feed Imporer',
                'Feed Importer',
                'manage_options',
                'casino_feed_importer',
                function ()
                {
                    require(plugin_dir_path(__FILE__) . 'views/importer.php');
                }
            );
        }

        add_submenu_page(
            'casino_feed',
            'Plugin Settings',
            'Plugin Settings',
            'manage_options',
            'casino_feed_settings',
            function ()
            {
                require(plugin_dir_path(__FILE__) . 'views/settings.php');
            }
        );
        add_submenu_page(
            null,
            'Casino Details',
            'Casino Details',
            'manage_options',
            'casino_feed_casino_details',
            function ()
            {
                require(plugin_dir_path(__FILE__) . 'views/details.php');
            }
        );
    }

    function casinofeed_register_status_enrpoint()
    {
        register_rest_route('casinofeed-plugin', 'status', array(
                'methods' => 'GET',
                'callback' => array($this, 'casinofeed_status')
            )
        );
    }

    function casinofeed_status()
    {
        return rest_ensure_response(array('status' => get_option("casinofeed_license_key_status")));
    }

    public function casinofeed_sync_data()
    {
        SyncHelper::sync();
        wp_die();
    }

    public function casinofeed_sync_taxonomy()
    {
        $type = sanitize_text_field($_POST['type']);
        $page = sanitize_text_field($_POST['page']);
        echo json_encode(TaxonomyHelper::syncTaxonomy($type, $page));
        wp_die();
    }

    // Elegance importer starts
    public function casinofeed_download_brand()
    {
        $ids = rest_sanitize_array($_POST['ids']);
        $sync = rest_sanitize_boolean($_POST['sync']);
        $search = empty($ids) ? [] : ['id' => $ids];
        $brands = SyncHelper::fetchBrands($search);

        foreach ($brands as $brand)
        {
            TaxonomyHelper::downloadBrand($brand, $sync);
        }
    }

    // Elegance importer
    public function casinofeed_set_license_key()
    {
        $nonce = sanitize_text_field($_POST['license_key']);
        update_option('casinofeed_license_key', $nonce);
        $status = self::LICENSE_KEY_STATUS_INACTIVE;
        if ($nonce)
        {
            $ts = time();
            $key = sha1(get_option('casinofeed_license_key') . "_$ts");
            $response = wp_remote_get(get_option('casinofeed_api_url') . "/activate?key=$key&ts=$ts");
            if (!isset($response['errors']))
            {
                $body = json_decode($response['body'], true);
                // this means no error was returned
                if (!isset($body['message']))
                {
                    $status = $body['status'];
                }
            }
        }
        update_option('casinofeed_license_key_status', $status);
        echo $status;
        wp_die();
    }

    public function casinofeed_approve_change()
    {
        $id = sanitize_text_field($_POST['id']);
        $type = sanitize_text_field($_POST['type']);
        SyncHelper::applyChanges($id, $type);
        wp_die();
    }

    public function casinofeed_skip_change()
    {
        $id = sanitize_text_field($_POST['id']);
        $type = sanitize_text_field($_POST['type']);
        SyncHelper::skipChange($id, $type);
        wp_die();
    }

    public function casinofeed_preview_shortcode()
    {
        $attribute = sanitize_text_field($_POST['attribute']);
        $brand = sanitize_text_field($_POST['brand_id']);
        $result = do_shortcode("[casino-data brand='$brand' field='$attribute']");

        echo <<<EOD
            <h2>Preview</h2>
			<p class="casino-feed-tip">$result</p>
			<h2>Shortcode</h2>
			<p class="casino-feed-tip">You can place this shortcode in any wordpress WYSIWYG Editor.</p>
			<p class="casino-feed-tip cf-text-right"><a href="#">copy</a></p>
			<input type="text" value='[casino-data brand="$brand" field="$attribute"]' disabled>
			<h2>PHP code</h2>
			<p class="casino-feed-tip">You can paste this code below inside your wordpress theme.</p>
			<p class="casino-feed-tip cf-text-right"><a href="#">copy</a></p>
			<input type="text" value="<?php echo do_shortcode('[casino-data brand='$brand' field='$attribute']');?>" disabled>
EOD;
        wp_die();
    }

    public function casinofeed_approve_all()
    {
        SyncHelper::applyAllChanges();
        wp_die();
    }

    public function casinofeed_set_update_type()
    {
        $nonce = sanitize_text_field($_POST['update_type']);
        if (in_array($nonce, [self::UPDATE_TYPE_MANUAL, self::UPDATE_TYPE_AUTOMATIC]))
        {
            update_option('casinofeed_update_type', $nonce);
            echo 'Update type changed successfully';
        }
        else
        {
            echo 'Invalid update type';
        }
        wp_die();
    }

    public function casino_data_shortcode($atts, $content = null)
    {
        if (!isset($atts['brand']) || !isset($atts['field']))
        {
            return '';
        }
        global $wpdb;
        $brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_brand WHERE unique_name = %s", [$atts['brand']]), ARRAY_A);
        if(!$brand)
        {
            return '';
        }

        switch ($atts['field'])
        {
            case 'name' : return isset($brand['name']) ? $brand['name'] : '';
            case 'min_deposit' : return isset($brand['min_deposit']) ? $brand['min_deposit'] : '';
            case 'min_withdraw' : return isset($brand['min_withdraw']) ? $brand['min_withdraw'] : '';
            case 'max_withdraw' : return isset($brand['max_withdraw']) ? $brand['max_withdraw'] : '';
            case 'cashout_time' : return isset($brand['cashout_time']) ? $brand['cashout_time'] : '';
            case 'games_count' : return isset($brand['games_count']) ? $brand['games_count'] : '';
            case 'owner' : return isset($brand['owner']) ? $brand['owner'] : '';
            case 'url' : return isset($brand['url']) ? $brand['url'] : '';
            case 'image_url' : return isset($brand['image_url']) ? $brand['image_url'] : '';
            case 'established' : return isset($brand['established']) ? $brand['established'] : '';
            case 'currencies' :
                if (isset($brand['currencies']) && is_array($arr = json_decode($brand['currencies'])))
                {
                    return implode(',', array_column($arr, 'code'));
                }
                return '';
            case 'game_types' :
                if (isset($brand['game_types']) && is_array($arr = json_decode($brand['game_types'])))
                {
                    return implode(',', array_column($arr, 'name'));
                }
                return '';
            case 'countries' :
                if (isset($brand['countries']) && is_array($arr = json_decode($brand['countries'])))
                {
                    return implode(',', array_column($arr, 'code'));
                }
                return '';
            case 'languages' :
                if (isset($brand['languages']) && is_array($arr = json_decode($brand['languages'])))
                {
                    return implode(',', array_column($arr, 'code'));
                }
                return '';
            case 'supported_languages' :
                if (isset($brand['supported_languages']) && is_array($arr = json_decode($brand['supported_languages'])))
                {
                    return implode(',', array_column($arr, 'code'));
                }
                return '';
            case 'deposit_methods' :
                if (isset($brand['deposit_methods']) && is_array($arr = json_decode($brand['deposit_methods'])))
                {
                    return implode(',', array_column($arr, 'name'));
                }
                return '';
            case 'providers' :
                if (isset($brand['providers']) && is_array($arr = json_decode($brand['providers'])))
                {
                    return implode(',', array_column($arr, 'name'));
                }
                return '';
            case 'withdrawal_methods' :
                if (isset($brand['withdrawal_methods']) && is_array($arr = json_decode($brand['withdrawal_methods'])))
                {
                    return implode(',', array_column($arr, 'name'));
                }
                return '';
            case 'licenses' :
                if (isset($brand['licenses']) && is_array($arr = json_decode($brand['licenses'])))
                {
                    return implode(',', array_column($arr, 'name'));
                }
                return '';
            case 'support_types' :
                if (isset($brand['support_types']) && is_array($arr = json_decode($brand['support_types'])))
                {
                    return implode(',', array_column($arr, 'name'));
                }
                return '';
        }
        return '';
    }

    public function casino_bonus_shortcode($atts, $content = null)
    {
        if (!isset($atts['brand']) || !isset($atts['field']))
        {
            return '';
        }
        global $wpdb;
        $brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_brand WHERE unique_name = %s", array($atts['brand'])), ARRAY_A);
        if(!$brand)
        {
            return '';
        }

        $countryCode = isset($atts['country']) ? $atts['country'] : '';
        $bonus = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_bonus WHERE brand_id = %s AND LOWER(country_code) = LOWER(%s) ", array($brand['id'], $countryCode)), ARRAY_A);

        switch ($atts['field'])
        {
            case 'brand_id' : return $bonus['brand_id'];
            case 'name' : return $bonus['name'];
            case 'amount' : return $bonus['amount'];
            case 'country_code' : return $bonus['country_code'];
            case 'currency_code' : return $bonus['currency_code'];
            case 'currency_sign' : return $bonus['currency_sign'];
            case 'free_spins' : return $bonus['free_spins'];
            case 'min_deposit' : return $bonus['min_deposit'];
            case 'min_bet' : return $bonus['min_bet'];
            case 'max_bet' : return $bonus['max_bet'];
            case 'valid_period' : return $bonus['valid_period'];
            case 'wagering_requirement' : return $bonus['wagering_requirement'];
            case 'terms_and_conditions' : return $bonus['terms_and_conditions'];
            case 'terms_and_conditions_url' : return $bonus['terms_and_conditions_url'];
        }
        return '';
    }

    /**
     * When plugin activated
     */
    public function casino_feed_plugin_activated()
    {
        $db = new DatabaseHelper();
        $db->init();

        $params = require_once(plugin_dir_path(__FILE__) . 'params.php');
        add_option('casinofeed_license_key', '');
        add_option('casinofeed_license_key_status', self::LICENSE_KEY_STATUS_INACTIVE);
        add_option('casinofeed_update_type', self::UPDATE_TYPE_MANUAL);
        add_option('casinofeed_total_brands', 0);
        add_option('casinofeed_followed_brands', 0);
        add_option('casinofeed_data_sync_date', '');
        add_option('casinofeed_api_url', $params['casinofeed_api_url']);
        add_option('casinofeed_url', $params['casinofeed_url']);
        // schedule the wp_cron responsible for synching (it should run once per hour, starting 1 hour after the installation)
        wp_schedule_event((new DateTime())->add(new DateInterval('PT1H'))->getTimestamp(), 'hourly', 'wp_cron_casino_feed_automatic_sync');
    }

    function casino_feed_plugin_db_update()
    {
        $db = new DatabaseHelper();
        $db->init();
    }

    public function casino_feed_plugin_deactivated()
    {
        wp_clear_scheduled_hook('wp_cron_casino_feed_automatic_sync');
    }

    /**
     * When plugin uninstalled
     */
    public function casino_feed_plugin_uninstalled()
    {
        global $wpdb;
        $brand_table_name = "{$wpdb->prefix}casinofeed_brand";
        $changed_brand_table_name = "{$wpdb->prefix}casinofeed_changed_brand";
        $bonus_table_name = "{$wpdb->prefix}casinofeed_bonus";
        $changed_bonus_table_name = "{$wpdb->prefix}casinofeed_changed_bonus";
        $recent_changes_table = "{$wpdb->prefix}casinofeed_recent_changes";
        $wpdb->query("DROP TABLE IF EXISTS $brand_table_name");
        $wpdb->query("DROP TABLE IF EXISTS $changed_brand_table_name");
        $wpdb->query("DROP TABLE IF EXISTS $bonus_table_name");
        $wpdb->query("DROP TABLE IF EXISTS $changed_bonus_table_name");
        $wpdb->query("DROP TABLE IF EXISTS $recent_changes_table");

        delete_option("casinofeed_db_version");
        delete_option("casinofeed_license_key");
        delete_option("casinofeed_license_key_status");
        delete_option("casinofeed_update_type");
        delete_option("casinofeed_total_brands");
        delete_option("casinofeed_followed_brands");
        delete_option("casinofeed_data_sync_date");
        delete_option("casinofeed_api_url");
        delete_option("casinofeed_url");
        wp_clear_scheduled_hook('wp_cron_casino_feed_automatic_sync');
    }
}

$cf = new Casino_Feed();
$cf->init();

register_activation_hook(__FILE__, 'Casino_Feed::casino_feed_plugin_activated');
register_deactivation_hook(__FILE__, 'Casino_Feed::casino_feed_plugin_deactivated');
register_uninstall_hook(__FILE__, 'Casino_Feed::casino_feed_plugin_uninstalled');
add_action('plugins_loaded', 'Casino_Feed::casino_feed_plugin_db_update');

// allow for SVG's to be downloaded and saved
function upload_svg_files( $allowed ) {
    if ( !current_user_can( 'manage_options' ) )
        return $allowed;
    $allowed['svg'] = 'image/svg+xml';
    return $allowed;
}
add_filter( 'upload_mimes', 'upload_svg_files');