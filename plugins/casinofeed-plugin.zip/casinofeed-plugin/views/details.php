<?php

if (!($id = sanitize_text_field($_GET['id'])))
{
    exit();
}
global $wpdb;
$brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_brand WHERE id = %d", array($id)), ARRAY_A);
if (!$brand)
{
    exit();
}
$recentChanges = SyncHelper::getRecentlyAppliedChanges($id);
$bonuses = $wpdb->get_results($wpdb->prepare("SELECT id, country_code FROM {$wpdb->prefix}casinofeed_bonus WHERE brand_id = %d", array($id)),  ARRAY_A);
?>

<div class="casino-feed-holder">
	<header class="casino-feed-header">
		<h1>Casino Feed / Casino Details / <?php echo $brand['name']; ?> </h1>
		<p class="casino-feed-tip">From this page you manage your casino feed connection & shortcodes. If you have a
			problem or question with any of these - <a href="#">Contact us</a></p>
	</header>

	<div class="casino-feed-main-row cf-justify-content-between">
		<div class="cf-cas-holder">
			<div class="casino-feed-sec-row cf-align-items-center">
				<div>
					<figure>
						<img src="<?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='image_url']") ;?>" alt="">
					</figure>
				</div>

				<div class="cf-cas-info">
					<h2><?php echo $brand['name']; ?> </h2>
					<span><?php echo $brand['updated_at']
                            ? date("Y-m-d", strtotime($brand['updated_at']))
                            : date("Y-m-d", strtotime($brand['created_at']));
                        ?> last update</span>
				</div>
			</div>
		</div>

		<div>
			<h1>You follow <?php echo get_option('casinofeed_followed_brands', 0) ?>
				of <?php echo get_option('casinofeed_total_brands', 0) ?> brands</h1>

			<div class="casino-feed-sec-row cf-align-items-center">
				<div>
					<p><strong>Want to get updates from more brands?</strong></p>
				</div>

				<div>
					<a class="button-primary" href="<?php echo get_option('casinofeed_url');?>">MANAGE BRANDS</a>
				</div>
			</div>
		</div>
	</div>

	<div class="cf-tab-details">
		<h1>Bonuses</h1>
		<header class="casino-feed-sec-row cf-align-items-center">
			<div class="cf-col-4">
				<span>Description</span>
			</div>
			<div class="cf-col-4">
				<span>Value</span>
			</div>
			<div class="cf-col-4">
				<span>Shortcode</span>
			</div>
		</header>
		<?php foreach ($bonuses as $bonus): ?>
			<?php $countryAttribute = !empty($bonus['country_code']) ? "country='{$bonus['country_code']}'" : ""?>
			<div class="casino-feed-collapsibles">
				<div class="casino-feed-single-collapsible">
					<div class="casino-feed-collapsible casino-feed-sec-row">
						<div class="cf-col-4">
							<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='name']") ?></span>
						</div>

						<div class="cf-col-4">
							<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='name']") ?></span>
						</div>

						<div class="cf-col-4">
							<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='name']" ?></span>
						</div>
					</div>

					<div class="casino-feed-detail-content">
						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Bonus Amount</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='amount']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='amount']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Free Spins</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='free_spins']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='free_spins']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Currency</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='currency_code']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='currency_code']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Currency sign</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='currency_sign']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='currency_sign']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Minumun deposit</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='min_deposit']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='min_deposit']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Minumun bet</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='min_bet']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='min_bet']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Maximum bet</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='max_bet']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='max_bet']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Valid for</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='valid_period']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='valid_period']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Wagering requirements</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='wagering_requirement']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='wagering_requirement']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Terms & Conditions</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='terms_and_conditions']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='terms_and_conditions']" ?></span>
							</div>
						</div>

						<div class="casino-feed-sec-row cf-single-detail">
							<div class="cf-col-4">
								<span>Terms & Conditions link</span>
							</div>

							<div class="cf-col-4">
								<span><?php echo do_shortcode("[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='terms_and_conditions_url']") ?></span>
							</div>

							<div class="cf-col-4">
								<span><?php echo "[casino-bonus brand='{$brand['unique_name']}' $countryAttribute field='terms_and_conditions_url']" ?></span>
							</div>
						</div>

					</div><!-- end  casino-feed-detail-content -->
				</div><!-- end  casino-feed-single-collapsible -->
			</div>
		<?php endforeach; ?>
	</div>


	<div class="cf-tab-details">
		<h1>General data</h1>

		<header class="casino-feed-sec-row cf-align-items-center">
			<div class="cf-col-4">
				<span>Description</span>
			</div>

			<div class="cf-col-4">
				<span>Value</span>
			</div>

			<div class="cf-col-4">
				<span>Shortcode</span>
			</div>
		</header>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Game types</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='game_types']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='game_types']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Software providers list</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='providers']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='software_providers']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method  casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Deposit methods</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='deposit_methods']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='deposit_methods']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Withdrawal methods</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='withdrawal_methods']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='withdrawal_methods']" ?></span>
			</div>
		</div>

		<div class="cf-licenses casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Licenses</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='licenses']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='licenses']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Currencies accepted</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='currencies']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='currencies']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Language versions</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='languages']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='languages']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Restricted countries</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='countries']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='countries']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Support language</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='supported_languages']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='supported_languages']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Minimum deposit</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='min_deposit']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='min_deposit']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Minimum Withdraw</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='min_withdraw']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='min_withdraw']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Maximum Withdraw</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='max_withdraw']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='max_withdraw']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Cashout time</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='cashout_time']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='cashout_time']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Support type</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='support_types']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='support_types']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Logo</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='image_url']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='image_url']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Owner</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='name']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='name']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Year founded</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='established']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='established']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Games Count</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='games_count']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='games_count']" ?></span>
			</div>
		</div>

		<div class="cf-payment-method casino-feed-sec-row">
			<div class="cf-col-4">
				<span>Owner</span>
			</div>

			<div class="cf-col-4">
				<span> <?php echo do_shortcode("[casino-data brand='{$brand['unique_name']}' field='owner']") ;?></span>
			</div>

			<div class="cf-col-4">
				<span><?php echo "[casino-data brand='{$brand['unique_name']}' field='owner']" ?></span>
			</div>
		</div>
	</div>

	<div class="casino-feed-available-updates">
		<h1>Recently updated</h1>

        <?php foreach ($recentChanges as $update): ?>
			<div class="casino-feed-sec-row cf-align-items-center casino-feed-avail-update">
				<div class="cf-col-1">
					<span><strong><?php echo $update['timestamp']; ?></strong></span>
				</div>

				<div class="cf-col-2">
					<h2><strong><?php echo $update['name']; ?></strong></h2>
				</div>

				<div class="">
                    <?php echo SyncHelper::formatChangeMessage($update['changes']) ?>
				</div>
			</div>
        <?php endforeach; ?>

	</div>
</div>
