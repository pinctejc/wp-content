<?php
global $wpdb;
$brands = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_brand"), ARRAY_A);
?>

<div class="casino-feed-holder">
	<header class="casino-feed-header">
		<h1>Casino Feed / Feed Browser</h1>
		<p class="casino-feed-tip">From this page you manage your casino feed connection & shortcodes. If you have a
			problem or question with any of these - <a href="#">Contact us</a></p>
	</header>

	<div class="cf-casinos-feed">
		<div class="casino-feed-main-row">
			<div>
				<h1>You follow <?php echo get_option('casinofeed_followed_brands', 0) ?>
					of <?php echo get_option('casinofeed_total_brands', 0) ?> brands</h1>

				<div class="casino-feed-sec-row cf-align-items-center">
					<div>
						<p><strong>Want to get updates from more brands?</strong></p>
					</div>

					<div>
						<a class="button-primary" href="<?php echo get_option('casinofeed_url');?>">MANAGE BRANDS</a>
					</div>
				</div>
			</div>

			<div>
				<h1>Data Sync</h1>
				<div class="casino-feed-sec-row cf-align-items-center">
					<div>
						<p><strong>Last Synced: <span class="last_synched"><?= SyncHelper::getLastSynchedElapsed()?></span></strong></p>
					</div>

					<div>
						<input id="casino-feed-sync_data" type="button" value="SYNC NOW" class="button-primary" />
					</div>
				</div>
			</div>

		</div>

		<div class="casino-feed-sec-row">
            <?php foreach ($brands as $brand) : ?>
				<div class="cf-col-4 cf-cas-holder">
					<div class="casino-feed-sec-row cf-align-items-center">
						<div>
							<figure>
								<img src="<?php echo $brand['image_url'] ?>" alt="">
							</figure>
						</div>

						<div class="cf-cas-info">
							<h2><?php echo $brand['name']; ?></h2>
							<span><?php echo $brand['updated_at']
                                    ? date("Y-m-d", strtotime($brand['updated_at']))
                                    : date("Y-m-d", strtotime($brand['created_at']));
                                ?> last update
                            </span>
							<a class="button-primary" href="<?php echo add_query_arg(array(
                                'page' => 'casino_feed_casino_details',
                                'id' => $brand['id']
                            ), admin_url('admin.php')); ?>">BROWSE DATA</a>
						</div>
					</div>
				</div>
            <?php endforeach; ?>
		</div>
	</div>

	<div class="casino-feed-shortcode-gen">
		<h1>Shortcode generator</h1>
		<p class="casino-feed-tip">General shortcodes for the casino you want.</p>

		<?php if(!empty($brands)): ?>
			<form>
				<div class="casino-feed-main-row">
					<div>
						<label>Casino</label>
						<select name="select" id="casino-feed-change-brand-shortcode">
                            <?php foreach ($brands as $brand): ?>
								<option value="<?php echo $brand['unique_name'] ?>"><?php echo $brand['name'] ?></option>
                            <?php endforeach; ?>
						</select>
					</div>

					<div>
						<label>Field</label>
						<select name="select" id="casino-feed-change-attribute-shortcode">
							<option value="name">name</option>
							<option value="min_deposit">min_deposit</option>
							<option value="min_withdraw">min_withdraw</option>
							<option value="max_withdraw">max_withdraw</option>
							<option value="cashout_time">cashout_time</option>
							<option value="url">url</option>
							<option value="image_url">image_url</option>
							<option value="established">established</option>
							<option value="games_count">games_count</option>
							<option value="owner">owner</option>
							<option value="currencies">currencies</option>
							<option value="game_types">game_types</option>
							<option value="countries">countries</option>
							<option value="languages">languages</option>
							<option value="supported_languages">supported_languages</option>
							<option value="deposit_methods">deposit_methods</option>
							<option value="providers">providers</option>
							<option value="withdrawal_methods">withdrawal_methods</option>
							<option value="licenses">licenses</option>
							<option value="support_types">support_types</option>
						</select>
					</div>
				</div>
			</form>

		<div class="casino-feed-preview-shortcode">

		</div>

        <?php endif; ?>
	</div>

	<p class="casino-feed-tip"><a href="#">Read Casino Feed Full documentation& WiKi</a></p>
</div>