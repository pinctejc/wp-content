<?php
global $wpdb;
ini_set('error_reporting',1);
ini_set('display_errors',1);

try
{
    $cfBrands = SyncHelper::fetchBrands();
	$stats = SyncHelper::fetchStats();
} catch (Exception $exception)
{
    $cfBrands = [];
    $stats = [];
}

$providerResponse = TaxonomyHelper::fetchTaxonomyData('provider', 1, 1);
$paymentMethodResponse = TaxonomyHelper::fetchTaxonomyData('payment', 1, 1);
$licensesResponse = TaxonomyHelper::fetchTaxonomyData('license', 1, 1);
$gameTypesResponse = TaxonomyHelper::fetchTaxonomyData('game-type', 1, 1);
$currenciesResponse = TaxonomyHelper::fetchTaxonomyData('currency', 1, 1);
$languagesResponse = TaxonomyHelper::fetchTaxonomyData('language', 1, 1);

$softwareProviders = isset($providerResponse->_meta->totalCount) ? $providerResponse->_meta->totalCount : 0;
$paymentMethods = isset($paymentMethodResponse->_meta->totalCount) ? $paymentMethodResponse->_meta->totalCount : 0;
$licenses = isset($licensesResponse->_meta->totalCount) ? $licensesResponse->_meta->totalCount : 0;
$gameTypes = isset($gameTypesResponse->_meta->totalCount) ? $gameTypesResponse->_meta->totalCount : 0;
$currencies = isset($currenciesResponse->_meta->totalCount) ? $currenciesResponse->_meta->totalCount : 0;
$languages = isset($languagesResponse->_meta->totalCount) ? $languagesResponse->_meta->totalCount : 0;

$taxonomyProviders = count(get_terms(['taxonomy' => 'provider', 'hide_empty' => false]));
$taxonomyPayment = count(get_terms(['taxonomy' => 'payment', 'hide_empty' => false]));
$taxonomyLicense = count(get_terms(['taxonomy' => 'license', 'hide_empty' => false]));
$taxonomyGameType = count(get_terms(['taxonomy' => 'game-type', 'hide_empty' => false]));
$taxonomyCurrency = count(get_terms(['taxonomy' => 'currency', 'hide_empty' => false]));
$taxonomyLanguage = count(get_terms(['taxonomy' => 'language', 'hide_empty' => false]));

?>
<div class="casino-feed-holder">

	<header class="casino-feed-header">
		<h1>Casino Feed Importer</h1>
		<p class="casino-feed-tip">From here you import post types and taxonomies to your local wordpress database</p>
	</header>
	
	<div class="casino-feed-main-row">
		<div style="width: 95%;">
		<h1>Taxonomies</h1>

		<div class="casino-feed-sec-row">
			<div>
				<p><strong>
					You have
					<span class="cf-total-synced-taxonomies">
						<?php echo $taxonomyProviders + $taxonomyPayment + $taxonomyLicense + $taxonomyGameType + $taxonomyCurrency + $taxonomyLanguage ?>
					</span>
					of
					<?php echo $softwareProviders + $paymentMethods + $licenses + $gameTypes + $currencies + $languages; ?>
					</strong>
			</div>

			<div>
				<input id="casino-feed-sync_all_taxonomies" type="button" value="SYNC ALL" class="button-primary">
			</div>
		</div>

		<table class="sync-talbe widefat" style="margin-top:20px;">
			<thead>
				<th>Taxonomy</th>
				<th>Casino Feed Records</th>
				<th>Wordpress DB Records</th>
				<th>Actions</th>
			</thead>
			<tbody>
				<tr>
					<td>Software providers</td>
					<td><?= $softwareProviders ?></td>
					<td class="cf-taxonomies-imported"><?= $taxonomyProviders ?></td>
					<td><input type="button" value="Sync now" class="sync-taxonomy button-primary" data-page="1" data-type="provider"></td>
				</tr>
				<tr>
					<td>Payment methods</td>
					<td><?= $paymentMethods ?></td>
					<td class="cf-taxonomies-imported"><?= $taxonomyPayment ?></td>
					<td><input type="button" value="Sync now" class="sync-taxonomy button-primary" data-page="1" data-type="payment"></td>
				</tr>
				<tr>
					<td>Licenses</td>
					<td><?= $licenses ?></td>
					<td class="cf-taxonomies-imported"><?= $taxonomyLicense ?></td>
					<td><input type="button" value="Sync now" class="sync-taxonomy button-primary" data-page="1" data-type="license"></td>
				</tr>
				<tr>
					<td>Game types</td>
					<td><?= $gameTypes ?></td>
					<td class="cf-taxonomies-imported"><?= $taxonomyGameType ?></td>
					<td><input type="button" value="Sync now" class="sync-taxonomy button-primary" data-page="1" data-type="game-type"></td>
				</tr>
				<tr>
					<td>Currencies</td>
					<td><?= $currencies ?></td>
					<td class="cf-taxonomies-imported"><?= $taxonomyCurrency ?></td>
					<td><input type="button" value="Sync now" class="sync-taxonomy button-primary" data-page="1" data-type="currency"></td>
				</tr>
				<tr>
					<td>Languages</td>
					<td><?= $languages ?></td>
					<td class="cf-taxonomies-imported"><?= $taxonomyLanguage ?></td>
					<td><input type="button" value="Sync now" class="sync-taxonomy button-primary" data-page="1" data-type="language"></td>
				</tr>

			</tbody>
		</table>

		<h1>Brands</h1>

		<div class="casino-feed-sec-row cf-align-items-center">
			<div>
				<p><strong>You have downloaded <?= count(get_posts(array('numberposts' => -1,'meta_key' => 'casino_feed_id')))?> of <?= $stats['followed_brands']?> brands you follow</strong></p>
			</div>

			<div>
				<input type="button" value="Download all missing" class="button-primary download-all-brands">
				<input type="button" value="Sync all downloaded" class="button-primary download-all-brands" data-sync="1">
			</div>
		</div>


		<table class="sync-talbe widefat" style="margin-top:20px;">
			<thead>
				<th><input type="checkbox" class="toggle-all-brands" /></th>
				<th> </th>
				<th>Brand</th>
				<th>Last updated on CF</th>
				<th>Last updated on WP DB</th>
				<th>Actions</th>
			</thead>
			<tbody>

			<?php foreach ($cfBrands as $brand) : ?>
				<tr>
					<?php
						$posts = get_posts(array('numberposts' => 1, 'meta_key' => 'casino_feed_id', 'meta_value' => $brand['unique_name']));
						$wpBrand = isset($posts[0]) ? $posts[0] : null;
					?>

					<td>
						<input type="checkbox" name="brands[]" value="<?php echo $brand['id']; ?>"/>
					</td>
					<td>
						<img src="<?php echo $brand['image_url'] ?>" width="20px" alt="">
					</td>
					<td><?php echo $brand['name']; ?> <br /> <em><?php echo $brand['unique_name']; ?></em></td>

					<td>
						<?php echo $wpBrand && $wpBrand->post_modified
							? date("Y-m-d H:i a", strtotime($wpBrand->post_modified))
							: ''
						?>
					</td>

					<td>
						<?php echo $brand['updated_at']
							? date("Y-m-d H:i a", strtotime($brand['updated_at']))
							: date("Y-m-d H:i a", strtotime($brand['created_at']));
						?>
					</td>

					<td>
						<input type="button"
							   value="Download"
							   class="button-primary download-casino-btn"
							   style="display: <?php echo !$wpBrand ? 'block' : 'none' ?>"
							   data-id="<?php echo $brand['id']; ?>"
							   data-progress="Downloading ..."
							   data-completed="Download"
						>
						<input type="button"
							   value="Sync now"
							   class="button-primary download-casino-btn"
							   style="display: <?php echo $wpBrand ? 'block' : 'none' ?>"
							   data-id="<?php echo $brand['id']; ?>"
							   data-progress="Synching ..."
							   data-completed="Sync now"
							   data-sync="1"
						>
					</td>
				</tr>

			<?php endforeach; ?>

			</tbody>
		</table>
		</div>
		<div class="casino-feed-sec-row cf-align-items-center" style="margin-top:10px">
			<div>
				<input type="button" value="Download selected" class="button-primary download-selected-brands">
				<input type="button" value="Sync selected" class="button-primary download-selected-brands" data-sync="1">
			</div>
		</div>
	</div>
</div>
<?php

