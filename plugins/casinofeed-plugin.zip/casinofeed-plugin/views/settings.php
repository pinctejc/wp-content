<div class="casino-feed-holder">
  <header class="casino-feed-header">
    <h1>Casino Feed / Settings</h1>
    <p class="casino-feed-tip">from this page you manage your casino feed connection & shortcodes If you have a problem or question with any of these - <a href="#">Contact us</a></p>
  </header>

  <div class="casino-feed-main-row casino-feed-license-form">
    <div>
      <h1>License</h1>
      <form>
        <input id="casino-feed-licence_key" class="casino-feed-license-input" type="text" name="license_key" placeholder="License Code" value="<?= get_option('casinofeed_license_key'); ?>"/>
	    <input id="casino-feed-license_key_submit" type="button" value="ACTIVATE" class="button-primary" />
      </form>
      <p id="license_key_status_container">
		  <?php $status = get_option('casinofeed_license_key_status')?>
		  <strong class="casinofeed-license-status-<?= Casino_Feed::LICENSE_KEY_STATUS_ACTIVE ?>" style="display: <?= $status == Casino_Feed::LICENSE_KEY_STATUS_ACTIVE ? '' : 'none' ?>">
			  License active. Connection Good
		  </strong>
		  <strong class="casinofeed-license-status-<?= Casino_Feed::LICENSE_KEY_STATUS_INACTIVE ?>" style="display: <?= $status == Casino_Feed::LICENSE_KEY_STATUS_INACTIVE ? '' : 'none' ?>">
			  License not active.
		  </strong>
	  </p>
    </div>

    <div>
      <h1>Data Sync</h1>
      <div class="casino-feed-sec-row cf-align-items-center">
        <div>
          <p><strong>Last Synced: <span class="last_synched"><?= SyncHelper::getLastSynchedElapsed()?></span></strong></p>
        </div>

        <div>
          <input id="casino-feed-sync_data" type="button" value="SYNC NOW" class="button-primary" />
        </div>
      </div>
    </div>
  </div>

  <div class="casino-feed-main-row">
    <div>
      <h1>Apply updates</h1>
      <p class="casino-feed-tip">Automatic updates will changeyour data whenever they are synced. Manual updates will need your approval for each of them in order to apply.</p>

	  <?php $updateType = get_option('casinofeed_update_type');?>
      <form>
        <label>
          <input type="radio" name="casinofeed_update_type" value="<?= Casino_Feed::UPDATE_TYPE_AUTOMATIC ?>" <?= $updateType == Casino_Feed::UPDATE_TYPE_AUTOMATIC ? 'checked': ''?>/> Automatically
        </label>

        <label>
          <input type="radio" name="casinofeed_update_type" value="<?= Casino_Feed::UPDATE_TYPE_MANUAL ?>" <?= $updateType == Casino_Feed::UPDATE_TYPE_MANUAL ? 'checked': ''?>/> Manually
        </label>

        <input id="casino-feed-update_type_submit" type="button" value="UPDATE" class="button-primary" />
      </form>
    </div>
  </div>

  <div class="casino-feed-main-row">
    <div>
	<h1>You follow <?php echo get_option('casinofeed_followed_brands', 0)?> of <?php echo get_option('casinofeed_total_brands', 0) ?> brands</h1>
      <p class="casino-feed-tip">If you want to follow more brands, go to your Casino Feed account and set up that. After that - Sync manually</p>

      <div class="casino-feed-sec-row cf-align-items-center">
        <div>
          <p><strong>Want to get updates from more brands?</strong></p>
        </div>

        <div>
          <a class="button-primary" href="<?php echo get_option('casinofeed_url');?>">MANAGE BRANDS</a>
        </div>
      </div>
    </div>
  </div>
</div>


