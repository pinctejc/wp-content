<?php
global $wpdb;
$availableUpdates = SyncHelper::getLastChanges();
$recentlyApplied = SyncHelper::getRecentlyAppliedChanges();
?>

<div class="casino-feed-holder">
	<header class="casino-feed-header">
		<h1>Casino Feed Updates</h1>
		<p class="casino-feed-tip">Updates settings. Set up if updates should apply automatically or manually</p>
	</header>

	<div class="casino-feed-main-row cf-justify-content-between">
		<div>
			<h1>Apply updates</h1>
            <?php $updateType = get_option('casinofeed_update_type');?>
			<form>
				<label>
					<input type="radio" name="casinofeed_update_type" value="<?= Casino_Feed::UPDATE_TYPE_AUTOMATIC ?>" <?= $updateType == Casino_Feed::UPDATE_TYPE_AUTOMATIC ? 'checked': ''?>/> Automatically
				</label>

				<label>
					<input type="radio" name="casinofeed_update_type" value="<?= Casino_Feed::UPDATE_TYPE_MANUAL ?>" <?= $updateType == Casino_Feed::UPDATE_TYPE_MANUAL ? 'checked': ''?>/> Manually
				</label>

				<input id="casino-feed-update_type_submit" type="button" value="UPDATE" class="button-primary" />
			</form>
		</div>

		<div>
			<h1>Data Sync</h1>
			<div class="casino-feed-sec-row cf-align-items-center">
				<div>
					<p><strong>Last Synced: <span class="last_synched"><?= SyncHelper::getLastSynchedElapsed()?></span></strong></p>
				</div>

				<div>
					<input id="casino-feed-sync_data" type="button" value="SYNC NOW" class="button-primary" />
				</div>
			</div>
		</div>

		<div>
			<h1>You follow <?php echo get_option('casinofeed_followed_brands', 0)?> of <?php echo get_option('casinofeed_total_brands', 0) ?> brands</h1>
			<div class="casino-feed-sec-row cf-align-items-center">
				<div>
					<p><strong>Want to get updates from more brands?</strong></p>
				</div>

				<div>
					<a class="button-primary" href="<?php echo get_option('casinofeed_url');?>">MANAGE BRANDS</a>
				</div>
			</div>
		</div>
	</div>

    <?php if (!empty($availableUpdates)): ?>
		<div class="casino-feed-available-updates">
			<div class="casino-feed-main-row cf-align-items-bottom cf-justify-content-between">
				<div>
					<h1>Available Updates (<?php echo count($availableUpdates);?>)</h1>
					<p class="casino-feed-tip">Updates settings. Set up if updates should apply automatically or
						manually</p>
				</div>

				<div>
					<button id="casino-feed-approve_all_changes" class="button-primary approve-all">APPROVE ALL</button>
				</div>
			</div>

            <?php foreach ($availableUpdates as $update): ?>
				<div
					class="casino-feed-sec-row cf-align-items-center cf-justify-content-between casino-feed-avail-update">
					<div class="cf-col-1">
						<span><strong><?php echo $update['timestamp']; ?></strong></span>
					</div>

					<div class="cf-col-2">
						<h2><strong><?php echo $update['name'] ?></strong></h2>
					</div>

					<div class="">
                        <?php echo SyncHelper::formatChangeMessage($update['changes'])?>
					</div>

					<div class="">
						<button class="casino-feed-approve_change button-primary single-buttons" data-id="<?php echo $update['id']?>" data-type="<?php echo $update['type']?>">APPROVE</button>
						<button class="casino-feed-skip_change button-primary single-buttons" data-id="<?php echo $update['id']?>" data-type="<?php echo $update['type']?>">SKIP</button>
					</div>
				</div>
            <?php endforeach; ?>
		</div>
    <?php endif; ?>

		<div class="casino-feed-available-updates">
			<h1>Recently applied</h1>
			<p class="casino-feed-tip">Recent updated feeds</p>

			<?php foreach ($recentlyApplied as $update): ?>
				<div class="casino-feed-sec-row cf-align-items-center casino-feed-avail-update">
					<div class="cf-col-1">
						<span><strong><?php echo $update['timestamp']; ?></strong></span>
					</div>

					<div class="cf-col-2">
						<h2><strong><?php echo $update['name']; ?></strong></h2>
					</div>

					<div class="">
						<?php echo SyncHelper::formatChangeMessage($update['changes'])?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
</div>
