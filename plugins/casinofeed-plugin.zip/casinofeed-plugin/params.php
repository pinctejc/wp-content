<?php 
        return array(
            'casinofeed_url' => 'http://app.casinofeed.net', 
            'casinofeed_api_url' => 'http://app.casinofeed.net/api',
        );