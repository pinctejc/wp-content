jQuery(document).ready(function($) {
	$('.download-casino-btn').click(function(ev) {
		ev.preventDefault();
		var button = $(this);
		var sync = button.data('sync');
		button.attr('disabled', true);
		button.val(button.data('progress'));
		button.closest('tr').addClass('inprogresss');

		$.post(ajaxurl, {
				action: 'casinofeed_download_brand',
				ids: [button.data('id')],
				sync: sync
			},
			function(status) {
				button.closest('tr').removeClass('inprogresss');
				button.attr('disabled', false);
				button.val(button.data('completed'));
				if(!sync) {
					button.closest('td').find('.download-casino-btn').toggle();
				}
			}
		);
	});

	$('.download-selected-brands').click(function(ev) {
		ev.preventDefault();
		var ids = [];
		jQuery('input[name="brands[]"]:checked').each(function() {
			var input = $(this);
			var row = input.closest('tr');
			var button = row.find('input[type="button"]');
			ids.push(input.val());
			row.addClass('inprogresss');
			button.attr('disabled', true);
			button.val('Downloading ...');
		});

		if(ids.length > 0) {
			$.post(ajaxurl, {
					action: 'casinofeed_download_brand',
					ids: ids,
					sync: $(this).data('sync')
				},
				function(status) {
					window.location.reload();
				}
			);
		}
	});

	$('.download-all-brands').click(function(ev) {
		ev.preventDefault();

		jQuery('input[name="brands[]"]').each(function() {
			var input = $(this);
			var row = input.closest('tr');
			var button = row.find('input[type="button"]');
			row.addClass('inprogresss');
			button.attr('disabled', true);
			button.val('Downloading ...');
		});

		$.post(ajaxurl, {
				action: 'casinofeed_download_brand',
				sync: $(this).data('sync')
			},
			function(status) {
				window.location.reload();
			}
		);
	});

	$('.toggle-all-brands').click(function(ev) {
		var checked = $(this).is(':checked');
		$('input[name="brands[]"]').each(function() {
			$(this).prop('checked', checked)
		});
	});

	$('#casino-feed-sync_all_taxonomies').click(function(ev) {
		ev.preventDefault();
		$('.sync-taxonomy').each(function() {
			var button = $(this);
			button.attr('disabled', true);
			button.val('Synching ...');
			button.closest('tr').addClass('inprogresss');

			syncTaxonomy(button);
		});
	});

	$('.sync-taxonomy').click(function(ev) {
		ev.preventDefault();
		var button = $(this);
		button.attr('disabled', true);
		button.val('Synching ...');
		button.closest('tr').addClass('inprogresss');

		syncTaxonomy(button);
	});

	function syncTaxonomy(button) {

		$.post(ajaxurl, {
				action: 'casinofeed_sync_taxonomy',
				type: button.data('type'),
				page: button.data('page'),
			},
			function(status) {
				var data = JSON.parse(status);
				button.closest('tr').find('.cf-taxonomies-imported').html(data.items);
				button.data('page', data.next_page);

				var totalSynced = 0;
				jQuery('.cf-taxonomies-imported')
					.each(function(el) {
						totalSynced += parseInt(jQuery(this).html());
					});
				jQuery('.cf-total-synced-taxonomies').html(totalSynced);

				if(data.progress == 100) {
					button.closest('tr').removeClass('inprogresss');
					button.attr('disabled', false);
					button.val('Sync now');
				} else {
					syncTaxonomy(button)
				}
			}
		);
	}
});