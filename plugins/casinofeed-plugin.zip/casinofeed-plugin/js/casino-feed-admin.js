//custom  plugin js goes here
jQuery(document).ready(function($) {

	$(".casino-feed-collapsible").click(function() {
		var holder = $(this).closest('.casino-feed-collapsibles');
		var parent = $(this).closest('.casino-feed-single-collapsible');
		var active_questions = holder.find('.cf-active-detail');

		if(!parent.hasClass('cf-active-detail')) {
			active_questions.find(".casino-feed-detail-content").stop(true).slideUp(300);
			active_questions.removeClass('cf-active-detail');
			parent.addClass('cf-active-detail');
			parent.find(".casino-feed-detail-content").stop(true).slideDown(300);
		} else {
			active_questions.find(".casino-feed-detail-content").stop(true).slideUp(300);
			active_questions.removeClass('cf-active-detail');
		}

		return false;
	});

	$('#casino-feed-license_key_submit').click(function(ev) {
		ev.preventDefault();
		$.post(ajaxurl, {
				action: 'casinofeed_set_license_key',
				license_key: $('#casino-feed-licence_key').val()
			},
			function(status) {
				$('#license_key_status_container strong').hide();
				$('#license_key_status_container strong.casinofeed-license-status-' + status).show();
			}
		);
	});

	$('#casino-feed-approve_all_changes').click(function(ev) {
		ev.preventDefault();
		$.post(ajaxurl, {
				action: 'casinofeed_approve_all',
			},
			function(status) {
				window.location.reload();
			}
		);
	});

	$('.casino-feed-approve_change').click(function(ev) {
		ev.preventDefault();
		$.post(ajaxurl, {
				action: 'casinofeed_approve_change',
				id: $(this).data('id'),
				type: $(this).data('type')
			},
			function(status) {
				window.location.reload();
			}
		);
	});

	$('.casino-feed-skip_change').click(function(ev) {
		ev.preventDefault();
		$.post(ajaxurl, {
				action: 'casinofeed_skip_change',
				id: $(this).data('id'),
				type: $(this).data('type')
			},
			function(status) {
				window.location.reload();
			}
		);
	});

	$('#casino-feed-update_type_submit').click(function(ev) {
		ev.preventDefault();
		$.post(ajaxurl, {
				action: 'casinofeed_set_update_type',
				update_type: $('input[name="casinofeed_update_type"]:checked').val()
			},
			function(response) {
				alert(response);
			}
		);
	});

	$('#casino-feed-sync_data').click(function(ev) {
		ev.preventDefault();
		var button = $(ev.target);
		button.prop('disabled', true);

		$.post(ajaxurl, {
				action: 'casinofeed_sync_data',
			},
			function(response) {
				window.location.reload();
			}
		);
	});

	function previewShortcodes() {
		$.post(ajaxurl, {
				action: 'casinofeed_preview_shortcode',
				brand_id: $('#casino-feed-change-brand-shortcode').val(),
				attribute: $('#casino-feed-change-attribute-shortcode').val(),
			},
			function(response) {
				$('.casino-feed-preview-shortcode').html(response);
			}
		);
	}

	let params = (new URL(document.location)).searchParams;
	if(params.get("page") == 'casino_feed_browser') {
		previewShortcodes();
	}

	$('#casino-feed-change-attribute-shortcode, #casino-feed-change-brand-shortcode').on('change', function(ev) {
		previewShortcodes();
	});
});