<?php


class SyncHelper
{
    public static function sync()
    {
        global $wpdb;
        $totalCount = null;
        $followedCount = null;

        $wpdb->query('START TRANSACTION');
        try
        {
            $brands = self::fetchBrands();

            self::fetchStats();

            self::syncData($brands);

            $wpdb->query('COMMIT');
        } catch (Exception $exception)
        {
            $wpdb->query('ROLLBACK');
        }

        update_option("casinofeed_data_sync_date", (new DateTime('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s'));
    }

    public static function fetchStats()
    {
        $ts = time();
        $key = sha1(get_option('casinofeed_license_key') . "_$ts");

        $response = wp_remote_get(get_option('casinofeed_api_url') . "/stats?key=$key&ts=$ts");

        if (isset($response['errors']))
        {
            throw new Exception('Request failed');
        }

        $body = json_decode($response['body'], true);
        if (isset($body['message']))
        {
            throw new Exception($body['message']);
        }

        update_option('casinofeed_total_brands', $body['total_brands']);
        update_option('casinofeed_followed_brands', $body['followed_brands']);

        return $body;
    }

    public static function fetchBrands($search = [])
    {
        $brands = [];
        $url = get_option('casinofeed_api_url') . "/sync";
        do
        {
            $ts = time();
            $key = sha1(get_option('casinofeed_license_key') . "_$ts");
            $queryParams = array_merge(['key' => $key, 'ts' => $ts], $search);
            $response = wp_remote_get("{$url}?" . http_build_query($queryParams));
            if (isset($response['errors']))
            {
                throw new Exception('Request failed');
            }

            $body = json_decode($response['body'], true);
            if (isset($body['message']))
            {
                throw new Exception($body['message']);
            }

            $url = isset($body['_links']['next']['href']) ? $body['_links']['next']['href'] : null;

            $brands = array_merge($brands, $body['items']);
        } while ($url != null);

        return $brands;
    }

    private static function syncData($brands)
    {
        global $wpdb;
        $existingBrands = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_brand"), ARRAY_A);
        $existingBonuses = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_bonus"), ARRAY_A);
        $autoUpdate = get_option('casinofeed_update_type') == Casino_Feed::UPDATE_TYPE_AUTOMATIC;

        $newBrandIds = [];
        $newBonusIds = [];
        // go through all the bonuses from the API, and check if they are changed.
        foreach ($brands as $brand)
        {
            $newBrandIds[] = $brand['id'];
            $existingBrand = self::findBrand($brand['id'], $existingBrands);
            if ($brandChanges = self::getBrandChanges($brand, $existingBrand))
            {
                self::insertBrand($brand, !$existingBrand || $autoUpdate, $brandChanges);
            }

            foreach ($brand['bonuses'] as $bonus)
            {
                $newBonusIds[] = $bonus['id'];
                $existingBonus = self::findBonus($bonus['id'], $existingBonuses);
                if ($bonusChanges = self::getBonusChanges($bonus, $existingBonus))
                {
                    self::insertBonus($bonus, !$existingBonus || $autoUpdate, $bonusChanges);
                }
            }
        }

        // remove the brands/bonuses that are not present in the api response
        foreach ($existingBonuses as $bonus)
        {
            if (!in_array($bonus['id'], $newBonusIds))
            {
                $bonus['removed'] = 1;
                $autoUpdate
                    ? self::removeBonus($bonus)
                    : self::insertBonus($bonus, false, ['message' => 'Bonus Removed']);
            }
        }

        foreach ($existingBrands as $brand)
        {
            if (!in_array($brand['id'], $newBrandIds))
            {
                $brand['removed'] = 1;
                $autoUpdate
                    ? self::removeBrand($brand)
                    : self::insertBrand($brand, false, ['message' => 'Brand Removed']);
            }
        }
    }

    public static function removeBrand($brand)
    {
        global $wpdb;

        $deleteChangedBrand = $wpdb->delete("{$wpdb->prefix}casinofeed_changed_brand", ['id' => $brand['id']]);
        $deleteChangedBonus = $wpdb->delete("{$wpdb->prefix}casinofeed_changed_bonus", ['brand_id' => $brand['id']]);
        $deleteBrand = $wpdb->delete("{$wpdb->prefix}casinofeed_brand", ['id' => $brand['id']]);
        $deleteBonus = $wpdb->delete("{$wpdb->prefix}casinofeed_bonus", ['brand_id' => $brand['id']]);

        if ($deleteChangedBrand === false || $deleteChangedBonus === false || $deleteBonus === false || $deleteBrand === false)
        {
            throw new Exception("Error while removing brand");
        }

        if ($deleteBrand)
        {
            $recentChange = $wpdb->insert("{$wpdb->prefix}casinofeed_recent_changes", [
                'name' => isset($brand['name']) ? $brand['name'] : '',
                'type' => 'brand',
                'brand_id' => $brand['id'],
                'changes' => json_encode(['message' => "Brand was removed"])
            ]);
            if ($recentChange === false)
            {
                throw new Exception("Error while creating recent changes");
            }
        }
    }

    public static function removeBonus($bonus)
    {
        global $wpdb;

        $deleteBonus = $wpdb->delete("{$wpdb->prefix}casinofeed_bonus", ['id' => $bonus['id']]);
        $deleteChangedBonus = $wpdb->delete("{$wpdb->prefix}casinofeed_changed_bonus", ['id' => $bonus['id']]);
        if ($deleteBonus === false || $deleteChangedBonus === false)
        {
            throw new Exception("Error while removing brand");
        }

        if($deleteBonus)
        {
            $recentChange = $wpdb->insert("{$wpdb->prefix}casinofeed_recent_changes", [
                'name' => isset($bonus['name']) ? $bonus['name'] : '',
                'type' => 'bonus',
                'brand_id' => $bonus['brand_id'],
                'bonus_id' => $bonus['id'],
                'changes' => json_encode(['message' => "Bonus was removed"])
            ]);
            if ($recentChange === false)
            {
                throw new Exception("Error while creating recent changes");
            }
        }
    }

    public static function skipChange($id, $type)
    {
        global $wpdb;
        if ($type == 'brand')
        {
            $wpdb->delete("{$wpdb->prefix}casinofeed_changed_brand", ['id' => $id]);
        }
        elseif ($type == 'bonus')
        {
            $wpdb->delete("{$wpdb->prefix}casinofeed_changed_bonus", ['id' => $id]);
        }
    }

    public static function applyChanges($id, $type)
    {
        global $wpdb;
        $wpdb->query('START TRANSACTION');
        try
        {
            if ($type == 'brand')
            {
                $brand = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_changed_brand WHERE id = %d", array($id)), ARRAY_A);
                if($brand)
                {
                    $brand['removed']
                        ? self::removeBrand($brand)
                        : self::insertBrand($brand, true, json_decode($brand['changes'], true));
                }
            }
            elseif($type == 'bonus')
            {
                $bonus = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_changed_bonus WHERE id = %d", array($id)), ARRAY_A);
                if($bonus)
                {
                    $bonus['removed']
                        ? self::removeBonus($bonus)
                        : self::insertBonus($bonus, true, json_decode($bonus['changes'], true));
                }
            }
            $wpdb->query('COMMIT');
        } catch (Exception $exception)
        {
            $wpdb->query('ROLLBACK');
        }
    }

    public static function applyAllChanges()
    {
        global $wpdb;
        $wpdb->query('START TRANSACTION');
        try
        {
            $existingBrands = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_changed_brand"), ARRAY_A);
            $existingBonuses = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}casinofeed_changed_bonus"), ARRAY_A);

            foreach ($existingBrands as $brand)
            {
                $brand['removed']
                    ? self::removeBrand($brand)
                    : self::insertBrand($brand, true, json_decode($brand['changes'], true));
            }

            foreach ($existingBonuses as $bonus)
            {
                $bonus['removed']
                    ? self::removeBonus($bonus)
                    : self::insertBonus($bonus, true, json_decode($brand['changes'], true));
            }

            $wpdb->query('COMMIT');
        } catch (Exception $exception)
        {
            $wpdb->query('ROLLBACK');
        }
    }

    /**
     * @param $newBonus array
     * @param $oldBonus array
     * @return array|false
     */
    private static function getBonusChanges($newBonus, $oldBonus)
    {
        if (!$oldBonus)
        {
            return ['message' => "Added bonus '{$newBonus['name']}'"];
        }

        // cast all the values to string, so we can compare them to the DB
        $newBonus = array_map('strval', $newBonus);
        $diff = array_diff_assoc($newBonus, $oldBonus);
        unset($diff['updated_at']);
        if (!empty($diff))
        {
            return ['message' => "Changed bonus '{$oldBonus['name']}'", 'changes' => $diff];
        }

        return false;
    }

    /**
     * @param $id
     * @param $bonuses array
     * @return array|null
     */
    private static function findBonus($id, $bonuses)
    {
        $index = array_search($id, array_column($bonuses, 'id'));
        return $index !== false ? $bonuses[$index] : null;
    }

    /**
     * @param $id
     * @param $brands array
     * @return array|null
     */
    private static function findBrand($id, $brands)
    {
        $index = array_search($id, array_column($brands, 'id'));
        return $index !== false ? $brands[$index] : null;
    }

    /**
     * @param $newBrand array
     * @param $oldBrand array
     * @return array|false
     */
    public static function getBrandChanges($newBrand, $oldBrand)
    {
        if (!$oldBrand)
        {
            return ['message' => "Added brand '{$newBrand['name']}'"];
        }

        // cast the values to string/json so we can compare them to the DB
        foreach ($newBrand as &$value)
        {
            $value = is_array($value) ? json_encode($value) : strval($value);
        }
        $diff = array_diff_assoc($newBrand, $oldBrand);
        unset($diff['updated_at']);
        unset($diff['bonuses']);

        if (!empty($diff))
        {
            return ['message' => "Changed bonus '{$oldBrand['name']}'", 'changes' => $diff];
        }

        return false;
    }

    /**
     * @param $brand array
     * @param $real boolean
     * @param $changes array
     * @throws Exception
     */
    public static function insertBrand(array $brand, $real = true, $changes = [])
    {
        global $wpdb;

        $columns = [
            'id' => $brand['id'],
            'name' => isset($brand['name']) ? $brand['name'] : '',
            'unique_name' => isset($brand['unique_name']) ? $brand['unique_name'] : '',
            'min_deposit' => isset($brand['min_deposit']) ? $brand['min_deposit'] : '',
            'min_withdraw' => isset($brand['min_withdraw']) ? $brand['min_withdraw'] : '',
            'games_count' => isset($brand['games_count']) ? $brand['games_count'] : '',
            'owner' => isset($brand['owner']) ? $brand['owner'] : '',
            'max_withdraw' => isset($brand['max_withdraw']) ? $brand['max_withdraw'] : '',
            'cashout_time' => isset($brand['cashout_time']) ? $brand['cashout_time'] : '',
            'url' => isset($brand['url']) ? $brand['url'] : '',
            'image_url' => isset($brand['image_url']) ? $brand['image_url'] : '',
            'established' => isset($brand['established']) ? $brand['established'] : '',
            'currencies' => isset($brand['currencies']) ? is_string($brand['currencies']) ? $brand['currencies'] : json_encode($brand['currencies']) : '',
            'game_types' => isset($brand['game_types']) ? is_string($brand['game_types']) ? $brand['game_types'] : json_encode($brand['game_types']) : '',
            'countries' => isset($brand['countries']) ? is_string($brand['countries']) ? $brand['countries'] : json_encode($brand['countries']) : '',
            'licenses' => isset($brand['licenses']) ? is_string($brand['licenses']) ? $brand['licenses'] : json_encode($brand['licenses']) : '',
            'languages' => isset($brand['languages']) ? is_string($brand['languages']) ? $brand['languages'] : json_encode($brand['languages']) : '',
            'supported_languages' => isset($brand['supported_languages']) ? is_string($brand['supported_languages']) ? $brand['supported_languages'] : json_encode($brand['supported_languages']) : '',
            'providers' => isset($brand['providers']) ? is_string($brand['providers']) ? $brand['providers'] : json_encode($brand['providers']) : '',
            'deposit_methods' => isset($brand['deposit_methods']) ? is_string($brand['deposit_methods']) ? $brand['deposit_methods'] : json_encode($brand['deposit_methods']) : '',
            'withdrawal_methods' => isset($brand['withdrawal_methods']) ? is_string($brand['withdrawal_methods']) ? $brand['withdrawal_methods'] : json_encode($brand['withdrawal_methods']) : '',
            'support_types' => isset($brand['support_types']) ? is_string($brand['support_types']) ? $brand['support_types'] : json_encode($brand['support_types']) : '',
            'created_at' => isset($brand['created_at']) && $brand['created_at'] ? $brand['created_at'] : null,
            'updated_at' => isset($brand['updated_at']) && $brand['updated_at'] ? $brand['updated_at'] : null,
        ];

        if ($real)
        {
            $table = "{$wpdb->prefix}casinofeed_brand";
            // the changes are going to be applied directly to the main table, so we save to the history as well
            self::changeApplied($changes, 'brand', $columns['id'], null, $columns['name']);
            // and remove the changes record
            if ($wpdb->delete("{$wpdb->prefix}casinofeed_changed_brand", ['id' => $columns['id']]) === false)
            {
                throw new Exception("Error while removing {$wpdb->prefix}casinofeed_changed_brand");
            }
        }
        else
        {
            $table = "{$wpdb->prefix}casinofeed_changed_brand";
            $columns['removed'] = isset($brand['removed']) ? $brand['removed'] : 0;
            $columns['changes'] = json_encode($changes);
        }

        if($wpdb->replace($table, $columns) === false)
        {
            throw new Exception("Error while saving $table");
        }
    }

    /**
     * @param $bonus array
     * @param $real boolean
     * @param $changes array
     * @throws Exception
     */
    public static function insertBonus(array $bonus, $real = true, $changes = [])
    {
        global $wpdb;

        $columns = [
            'id' => $bonus['id'],
            'brand_id' => $bonus['brand_id'],
            'name' => isset($bonus['name']) ? $bonus['name'] : '',
            'amount' => isset($bonus['amount']) ? $bonus['amount'] : '',
            'country_code' => isset($bonus['country_code']) ? $bonus['country_code'] : '',
            'currency_code' => isset($bonus['currency_code']) ? $bonus['currency_code'] : '',
            'currency_sign' => isset($bonus['currency_sign']) ? $bonus['currency_sign'] : '',
            'free_spins' => isset($bonus['free_spins']) ? $bonus['free_spins'] : '',
            'min_deposit' => isset($bonus['min_deposit']) ? $bonus['min_deposit'] : '',
            'min_bet' => isset($bonus['min_bet']) ? $bonus['min_bet'] : '',
            'max_bet' => isset($bonus['max_bet']) ? $bonus['max_bet'] : '',
            'valid_period' => isset($bonus['valid_period']) ? $bonus['valid_period'] : '',
            'wagering_requirement' => isset($bonus['wagering_requirement']) ? $bonus['wagering_requirement'] : '',
            'terms_and_conditions' => isset($bonus['terms_and_conditions']) ? $bonus['terms_and_conditions'] : '',
            'terms_and_conditions_url' => isset($bonus['terms_and_conditions_url']) ? $bonus['terms_and_conditions_url'] : '',
            'created_at' => isset($bonus['created_at']) ? $bonus['created_at'] : '',
            'updated_at' => isset($bonus['updated_at']) ? $bonus['updated_at'] : '',
        ];

        if ($real)
        {
            $table = "{$wpdb->prefix}casinofeed_bonus";
            // the changes are going to be applied directly to the main table, so we save to the history as well
            self::changeApplied($changes, 'bonus', $bonus['brand_id'], $bonus['id'], $columns['name']);
            // and remove the changes record
            if ($wpdb->delete("{$wpdb->prefix}casinofeed_changed_bonus", ['id' => $columns['id']]) === false)
            {
                throw new Exception("Error while removing {$wpdb->prefix}casinofeed_changed_bonus");
            }
        }
        else
        {
            $table = "{$wpdb->prefix}casinofeed_changed_bonus";
            $columns['removed'] = isset($bonus['removed']) ? $bonus['removed'] : 0;
            $columns['changes'] = json_encode($changes);
        }

        if($wpdb->replace($table, $columns) === false)
        {
            throw new Exception("Error while saving $table");
        }
    }

    /**
     * @return array
     */
    public static function getLastChanges()
    {
        global $wpdb;
        $bonuses = $wpdb->get_results($wpdb->prepare("SELECT id, name, changes, timestamp, 'bonus' as type  FROM {$wpdb->prefix}casinofeed_changed_bonus"), ARRAY_A);
        $brands = $wpdb->get_results($wpdb->prepare("SELECT id, name, changes, timestamp, 'brand' as type FROM {$wpdb->prefix}casinofeed_changed_brand"), ARRAY_A);
        $all =  array_merge($bonuses, $brands);

        usort($all, function ($a, $b) {
            $t1 = strtotime($a['timestamp']);
            $t2 = strtotime($b['timestamp']);
            return $t1 - $t2;
        });

        return $all;
    }

    public static function getRecentlyAppliedChanges($brand_id = null)
    {
        global $wpdb;
        $where = '';
        $params = array();
        if ($brand_id !== null)
        {
            $where = ' WHERE brand_id = %d';
            $params[] = $brand_id;
        }
        $query = "SELECT * FROM {$wpdb->prefix}casinofeed_recent_changes {$where} ORDER BY id DESC LIMIT 50";
        return $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
    }

    /**
     * @param $changes array
     * @param $type string
     * @param $name string
     * @throws Exception
     */
    private static function changeApplied($changes, $type, $brandId, $bonusId = null, $name = '')
    {
        global $wpdb;
        if ($wpdb->insert("{$wpdb->prefix}casinofeed_recent_changes", [
                'name' => $name,
                'type' => $type,
                'brand_id' => $brandId,
                'bonus_id' => $bonusId,
                'changes' => json_encode($changes)
            ]) === false)
        {
            throw new Exception("Error while saving {$wpdb->prefix}casinofeed_recent_changes");
        }
    }

    /**
     * @param $changes string|array
     * @return string
     */
    public static function formatChangeMessage($changes)
    {
        $msg = '';
        if (is_string($changes))
        {
            $changes = json_decode($changes, true);
        }

        if (isset($changes['message']))
        {
            $msg .= "<p>{$changes['message']}</p>";
        }

        if (isset($changes['changes']))
        {
            foreach ($changes['changes'] as $field => $change)
            {
                $change = print_r($change, true);
                if (strlen($change) > 30)
                {
                    $change = substr($change, 0, 30);
                    $change .= '...';
                }
                $msg .= "<h3> $field changed to $change</h3>";
            }
        }

        return $msg;
    }

    /**
     * @throws Exception
     */
    public static function getLastSynchedElapsed()
    {
        $datetime = get_option("casinofeed_data_sync_date");
        if ($datetime)
        {
            $now = new DateTime();
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);

            $diff->w = floor($diff->d / 7);
            $diff->d -= $diff->w * 7;

            $string = array(
                'y' => 'year',
                'm' => 'month',
                'w' => 'week',
                'd' => 'day',
                'h' => 'hour',
                'i' => 'minute',
                's' => 'second',
            );
            foreach ($string as $k => &$v)
            {
                if ($diff->$k)
                {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                }
                else
                {
                    unset($string[$k]);
                }
            }

            $string = array_slice($string, 0, 1);
            return $string ? implode(', ', $string) . ' ago' : 'just now';
        }
        return 'never';
    }
}