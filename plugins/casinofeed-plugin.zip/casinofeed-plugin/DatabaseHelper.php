<?php

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

class DatabaseHelper
{
    private $dbVersion = 2;

    public function init()
    {
        global $wpdb;

        $currentDbVersion = get_option('casinofeed_db_version');

        $brand_table_name = "{$wpdb->prefix}casinofeed_brand";
        $changed_brand_table_name = "{$wpdb->prefix}casinofeed_changed_brand";
        $bonus_table_name = "{$wpdb->prefix}casinofeed_bonus";
        $changed_bonus_table_name = "{$wpdb->prefix}casinofeed_changed_bonus";
        $recent_changes_table = "{$wpdb->prefix}casinofeed_recent_changes";
        $charset_collate = $wpdb->get_charset_collate();

        if (!$currentDbVersion)
        {
            dbDelta("
                CREATE TABLE $brand_table_name (
                  id INT NOT NULL,
                  name varchar(255) DEFAULT NULL,
                  unique_name varchar(255) DEFAULT NULL,
                  min_deposit varchar(255) DEFAULT NULL,
                  min_withdraw varchar(255) DEFAULT NULL,
                  max_withdraw varchar(255) DEFAULT NULL,
                  cashout_time varchar(255) DEFAULT NULL,
                  url TEXT,
                  image_url TEXT,
                  currencies TEXT,
                  game_types TEXT,
                  countries TEXT,
                  languages TEXT,
                  supported_languages TEXT,
                  providers TEXT,
                  deposit_methods TEXT,
                  withdrawal_methods TEXT,
                  support_types TEXT,
                  established TEXT,
                  created_at datetime,
                  updated_at datetime,
                  PRIMARY KEY (`id`)
                ) $charset_collate;

                CREATE TABLE $changed_brand_table_name (
                  id INT NOT NULL,
                  name varchar(255) DEFAULT NULL,
                  unique_name varchar(255) DEFAULT NULL,
                  min_deposit varchar(255) DEFAULT NULL,
                  min_withdraw varchar(255) DEFAULT NULL,
                  max_withdraw varchar(255) DEFAULT NULL,
                  cashout_time varchar(255) DEFAULT NULL,
                  url TEXT,
                  image_url TEXT,
                  currencies TEXT,
                  game_types TEXT,
                  countries TEXT,
                  languages TEXT,
                  supported_languages TEXT,
                  providers TEXT,
                  deposit_methods TEXT,
                  withdrawal_methods TEXT,
                  support_types TEXT,
                  established TEXT,
                  created_at datetime,
                  updated_at datetime,
                  changes text,
                  removed INT,
                  timestamp timestamp NOT NULL,
                  PRIMARY KEY (`id`)
                ) $charset_collate;

                CREATE TABLE $bonus_table_name (
                  id INT NOT NULL,
                  brand_id varchar(255) NOT NULL,
                  name varchar(255) NOT NULL,
                  amount varchar(255) DEFAULT NULL,
                  country_code varchar(255) DEFAULT NULL,
                  currency_code varchar(255) DEFAULT NULL,
                  currency_sign varchar(255) DEFAULT NULL,
                  free_spins varchar(255) DEFAULT NULL,
                  min_deposit varchar(255) DEFAULT NULL,
                  min_bet varchar(255) DEFAULT NULL,
                  max_bet varchar(255) DEFAULT NULL,
                  valid_period varchar(255) DEFAULT NULL,
                  wagering_requirement varchar(255) DEFAULT NULL,
                  terms_and_conditions text DEFAULT NULL,
                  terms_and_conditions_url text DEFAULT NULL,
                  created_at datetime,
                  updated_at datetime,
                  PRIMARY KEY (`id`)
                ) $charset_collate;   

                CREATE TABLE $changed_bonus_table_name (
                  id INT NOT NULL,
                  brand_id varchar(255) NOT NULL,
                  name varchar(255) NOT NULL,
                  amount varchar(255) DEFAULT NULL,
                  country_code varchar(255) DEFAULT NULL,
                  currency_code varchar(255) DEFAULT NULL,
                  currency_sign varchar(255) DEFAULT NULL,
                  free_spins varchar(255) DEFAULT NULL,
                  min_deposit varchar(255) DEFAULT NULL,
                  min_bet varchar(255) DEFAULT NULL,
                  max_bet varchar(255) DEFAULT NULL,
                  valid_period varchar(255) DEFAULT NULL,
                  wagering_requirement varchar(255) DEFAULT NULL,
                  terms_and_conditions text DEFAULT NULL,
                  terms_and_conditions_url text DEFAULT NULL,
                  created_at datetime,
                  updated_at datetime,
                  changes text,
                  removed INT,
                  timestamp timestamp NOT NULL,
                  PRIMARY KEY (`id`)
                ) $charset_collate;

                CREATE TABLE $recent_changes_table (
                  id INT NOT NULL AUTO_INCREMENT,
                  brand_id INT NOT NULL,
                  bonus_id INT,
                  name varchar(255),
                  type varchar(255) NOT NULL,
                  changes text,
                  timestamp timestamp NOT NULL,
                  PRIMARY KEY (`id`)
                ) $charset_collate;
            ");
            $currentDbVersion = 1;
            add_option('casinofeed_db_version', $currentDbVersion);
        }

        if ($currentDbVersion < $this->dbVersion)
        {
            $wpdb->query("ALTER TABLE $brand_table_name ADD COLUMN wp_last_update_date DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER updated_at;");
            $wpdb->query("ALTER TABLE $brand_table_name ADD COLUMN licenses TEXT AFTER currencies;");
            $wpdb->query("ALTER TABLE $brand_table_name ADD COLUMN games_count varchar(255) DEFAULT NULL AFTER cashout_time;");
            $wpdb->query("ALTER TABLE $brand_table_name ADD COLUMN owner varchar(255) DEFAULT NULL AFTER unique_name;");
            $wpdb->query("ALTER TABLE $changed_brand_table_name ADD COLUMN licenses TEXT AFTER currencies;");
            $wpdb->query("ALTER TABLE $changed_brand_table_name ADD COLUMN games_count varchar(255) DEFAULT NULL AFTER cashout_time;");
            $wpdb->query("ALTER TABLE $changed_brand_table_name ADD COLUMN owner varchar(255) DEFAULT NULL AFTER unique_name;");
            $currentDbVersion = 2;
            update_option('casinofeed_db_version', $currentDbVersion);
        }
    }
}