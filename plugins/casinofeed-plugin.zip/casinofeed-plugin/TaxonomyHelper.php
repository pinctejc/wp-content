<?php


class TaxonomyHelper
{

    private static function saveCurrencyTaxonomy($taxonomy, $item)
    {
        $term = get_term_by('name', $item->code, $taxonomy);
        if (!$term)
        {
            $insert_result = wp_insert_term(
                $item->code,
                $taxonomy,
                array('description' => $item->name, 'slug' => sanitize_title($item->code))
            );
            $term_id = ($insert_result instanceof WP_Error) ? null : $insert_result['term_id'];
        }
        else
        {
            $term_id = $term->term_id;
        }

        if ($term_id && isset($item->sign) && $item->sign != '')
        {
            $termMeta = get_term_meta($term_id);
            if (!isset($termMeta['sign']))
            {
                add_term_meta($term_id, "symbol", $item->sign);
            }
        }

        return $term_id;
    }

    private static function saveTaxonomy($taxonomy, $item)
    {
        $term = get_term_by('name', $item->name, $taxonomy);
        if (!$term)
        {
            $insert_result = wp_insert_term(
                $item->name,
                $taxonomy,
                array('description' => $item->description, 'slug' => sanitize_title($item->name))
            );
            $term_id = ($insert_result instanceof WP_Error) ? null : $insert_result['term_id'];
        }
        else
        {
            $term_id = $term->term_id;
        }

        if ($term_id && isset($item->image_url) && $item->image_url != '')
        {
            $termMeta = get_term_meta($term_id);
            if (!isset($termMeta['logo']) && $attachment_id = self::cf_insert_attachment_from_url($item->image_url))
            {
                update_field("logo", $attachment_id, 'term_' . $term_id);
            }
        }

        return $term_id;
    }

    public static function syncTaxonomy($taxonomy, $page = 1)
    {
        $data = self::fetchTaxonomyData($taxonomy, $page, 1);
        if (!$data)
        {
            return [
                'progress' => 100,
                'next_page' => 1,
                'items' => count(get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]))
            ];
        }
        foreach ($data->items as $item)
        {
            switch ($taxonomy)
            {
                case 'currency':
                    self::saveCurrencyTaxonomy($taxonomy, $item);
                    break;
                default:
                    self::saveTaxonomy($taxonomy, $item);
            }
        }

        $progress = ($data->_meta->currentPage / $data->_meta->pageCount) * 100;
        return [
            'progress' => $progress,
            'next_page' => $progress == 100 ? 1 : ++$page,
            'items' => count(get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]))
        ];
    }

    public static function cf_insert_attachment_from_url($url, $parent_post_id = null)
    {
        if (!class_exists('WP_Http'))
        {
            include_once(ABSPATH . WPINC . '/class-http.php');
        }

        $http = new WP_Http();
        $response = $http->request($url);
        if ($response['response']['code'] != 200)
        {
            return false;
        }

        $upload = wp_upload_bits(basename($url), null, $response['body']);
        if (!empty($upload['error']))
        {
            return false;
        }

        $file_path = $upload['file'];
        $file_name = basename($file_path);
        $file_type = wp_check_filetype($file_name, null);
        $attachment_title = sanitize_file_name(pathinfo($file_name, PATHINFO_FILENAME));
        $wp_upload_dir = wp_upload_dir();

        $post_info = array(
            'guid' => $wp_upload_dir['url'] . '/' . $file_name,
            'post_mime_type' => $file_type['type'],
            'post_title' => $attachment_title,
            'post_content' => '',
            'post_status' => 'inherit',
        );

        // Create the attachment
        $attach_id = wp_insert_attachment($post_info, $file_path, $parent_post_id);

        // Include image.php
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        // Define attachment metadata
        $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);

        // Assign metadata to attachment
        wp_update_attachment_metadata($attach_id, $attach_data);

        return $attach_id;
    }

    public static function fetchTaxonomyData($type, $page = 1, $perPage = 25)
    {
        $license = get_option('casinofeed_license_key');
        $ts = time();
        $key = sha1($license . "_" . $ts);
        $api_urls = array(
            'game-type' => get_option('casinofeed_api_url') . "/game-types?key=$key&ts=$ts&page=$page&per-page=$perPage",
            'payment' => get_option('casinofeed_api_url') . "/payment-methods?key=$key&ts=$ts&page=$page&per-page=$perPage",
            'provider' => get_option('casinofeed_api_url') . "/software-providers?key=$key&ts=$ts&page=$page&per-page=$perPage",
            'license' => get_option('casinofeed_api_url') . "/licenses?key=$key&ts=$ts&page=$page&per-page=$perPage",
            'currency' => get_option('casinofeed_api_url') . "/currencies?key=$key&ts=$ts&page=$page&per-page=$perPage",
            'language' => get_option('casinofeed_api_url') . "/languages?key=$key&ts=$ts&page=$page&per-page=$perPage",
        );
        if (isset($api_urls[$type]))
        {
            $response = wp_remote_get($api_urls[$type]);
            if (!isset($response['errors']))
            {
                return json_decode($response['body']);
            }
        }
        return false;
    }

    public static function downloadBrand($brand, $sync = false)
    {
        $restrictedCountries = [];
        $brandCountries = array_map('mb_strtolower', array_column($brand['countries'], 'code'));
        $wordpressCountries = get_posts(array('numberposts' => -1, 'post_type' => 'country'));

        foreach ($wordpressCountries as $cnt)
        {
            if (in_array(mb_strtolower($cnt->post_name), $brandCountries))
            {
                $restrictedCountries[] = $cnt->ID;
            }
        }

        $posts = get_posts(array(
            'numberposts' => 1,
            'meta_key' => 'casino_feed_id',
            'post_type' => 'post',
            'meta_value' => $brand['unique_name']
        ));

        $currencyTerms = array();
        foreach ($brand['currencies'] as $currency)
        {
            if ($term = get_term_by('name', $currency['code'], 'currency'))
            {
                $currencyTerms[] = $term->term_id;
            }
        }

        $metaInput = array(
            //affiliate url TO BE CHANGED WITH BRAND URL
            'affiliate_url' => $brand['url'],
            'website' => $brand['url'],
            'casino_feed_id' => $brand['unique_name'],
            'casino_games' => $brand['games_count'],
            'owner' => $brand['owner'],
            'rating' => '4.9',
            //year founded FORMAT TO BE FIXED
            'year_founded' => $brand['established'],
            'minimum_deposit' => $brand['min_deposit'],
            'minimum_withdrawal' => $brand['min_withdraw'],
            'maximum_withdraw' => $brand['max_withdraw'],
            'withraway_time' => $brand['cashout_time'],
            'software_providers' => (self::cf_taxonomy_to_wp_array($brand['providers'], 'provider')),
            'game_types' => (self::cf_taxonomy_to_wp_array($brand['game_types'], 'game-type')),
            'deposit_methods' => (self::cf_taxonomy_to_wp_array($brand['deposit_methods'], 'payment')),
            'withdraw_methods' => (self::cf_taxonomy_to_wp_array($brand['withdrawal_methods'], 'payment')),
            'licenses' => (self::cf_taxonomy_to_wp_array($brand['licenses'], 'license')),
            'languages' => (self::cf_taxonomy_to_wp_array($brand['languages'], 'language')),
            'support_languages' => (self::cf_taxonomy_to_wp_array($brand['supported_languages'], 'language')),
            'restricted' => $restrictedCountries,
            'currencies' => $currencyTerms,
        );

        $supportTypes = array_column($brand['support_types'], 'name');
        $types = [
            'email' => 'Email',
            'live_chat' => 'Live chat',
            'phone' => 'Phone',
            'working_hours' => 'Ticketing system',
        ];
        foreach ($types as $key => $value)
        {
            $val = 'No';
            if (($supportTypeIndex = array_search($value, $supportTypes)) !== false)
            {
                $val = isset($brand['support_types'][$supportTypeIndex]['value']) && $brand['support_types'][$supportTypeIndex]['value']
                    ? $brand['support_types'][$supportTypeIndex]['value']
                    : 'Yes';
            }
            $metaInput[$key] = $val;
        }

        $countrySpecificBonuses = [];
        foreach ($brand['bonuses'] as $bonus)
        {
            $bonus_currency = get_term_by('name', $bonus['currency_code'], 'currency');

            if (!$bonus['country_code'])
            {
                $bonuses['welcome_bonus'] = $bonus['name'];
                $bonuses['free_spins'] = $bonus['free_spins'];
                $bonuses['bonus_amount'] = $bonus['amount'];
                $bonuses['wagering'] = $bonus['wagering_requirement'];
                $bonuses['minimum_deposit'] = $bonus['min_deposit'];
                $bonuses['minimum_bet'] = $bonus['min_bet'];
                $bonuses['maximum_bet'] = $bonus['max_bet'];
                $bonuses['valid_period'] = $bonus['valid_period'];
                $bonuses['bonus_terms'] = $bonus['terms_and_conditions'];
                $bonuses['bonus_terms_url'] = $bonus['terms_and_conditions_url'];
                $bonuses['currency'] = $bonus_currency->term_id;
            }
            else
            {
                $countryId = null;
                foreach ($wordpressCountries as $cnt)
                {
                    if (mb_strtolower($cnt->post_name) == mb_strtolower($bonus['country_code']))
                    {
                        $countryId = $cnt->ID;
                        break;
                    }
                }

                $countrySpecificBonuses[] = [
                    'welcome_bonus' => $bonus['name'],
                    'free_spins' => $bonus['free_spins'],
                    'bonus_amount' => $bonus['amount'],
                    'wagering' => $bonus['wagering_requirement'],
                    'minimum_deposit' => $bonus['min_deposit'],
                    'minimum_bet' => $bonus['min_bet'],
                    'maximum_bet' => $bonus['max_bet'],
                    'valid_period' => $bonus['valid_period'],
                    'bonus_terms' => $bonus['terms_and_conditions'],
                    'bonus_terms_url' => $bonus['terms_and_conditions_url'],
                    'currency' => $bonus_currency->term_id,
                    'country' => $countryId,
                ];
            }
        }

        if (empty($posts))
        {
            $post = array(
                'post_title' => $brand['name'],
                'post_content' => "<p>" . $brand['name'] . " Review. This post was generated by CasinoFeed.net, please add your review here.</p>",
                'post_status' => 'publish',
            );

            if ($post_id = wp_insert_post($post))
            {
                $attachment_id = self::cf_insert_attachment_from_url($brand['image_url'], $post_id);
                set_post_thumbnail($post_id, $attachment_id);
                foreach ($metaInput as $key => $value)
                {
                    update_field($key, $value, $post_id);
                }
                if (isset($bonuses) && $bonuses)
                {
                    update_field('default_bonuses', $bonuses, $post_id);
                }
            }
            foreach ($countrySpecificBonuses as $countryBonus)
            {
                add_row('geo_targeted_bonuses', $countryBonus, $post_id);
            }
        }
        elseif (!empty($posts) && isset($posts[0]) && $sync)
        {
            foreach ($metaInput as $key => $value)
            {
                update_field($key, $value, $posts[0]->ID);
            }
            if (isset($bonuses) && $bonuses)
            {
                update_field('default_bonuses', $bonuses, $posts[0]->ID);
            }
            $attachment_id = self::cf_insert_attachment_from_url($brand['image_url'], $posts[0]->ID);
            set_post_thumbnail($posts[0]->ID, $attachment_id);

            delete_field('geo_targeted_bonuses', $posts[0]->ID);
            foreach ($countrySpecificBonuses as $countryBonus)
            {
                add_row('geo_targeted_bonuses', $countryBonus, $posts[0]->ID);
            }
        }
    }

    protected static function cf_taxonomy_to_wp_array($arr, $taxonomy_type)
    {
        $return_arr = array();
        foreach ($arr as $item)
        {
            if ($term = get_term_by('name', $item['name'], $taxonomy_type))
            {
                $return_arr[] = $term->term_id;
            }
        }

        return $return_arr;
    }

}